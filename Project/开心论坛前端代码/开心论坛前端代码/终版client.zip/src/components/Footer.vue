 <template lang="html">
        <div class="footer">
          <ul>
            <li>关于我们</li>
            <li>帮助中心</li>
            <li>商务合作</li>
            <li>开放平台</li>
            <li>搜索推荐</li>
            <li>友情链接</li>
          </ul>
          <p> © 2020  开心论坛</p>
        </div>
 </template>

 <script>
export default {
}
</script>

 <style scoped>
.footer{
  position: absolute;
  width:99%;
  background-color: #2B3D43;
  color:#feffff;
  margin-top: 1200px;
  font-size: 13px;
  text-align: center;
}
li{
  display: inline-block;
  cursor: pointer;
  padding: 0 6px;
  border-right: 2px solid #feffff;
}
</style>